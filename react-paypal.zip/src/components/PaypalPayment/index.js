import React, { useState, useEffect } from 'react';
import './index.css';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import validator from 'validator'
toast.configure()
const PaypalPayment = () => {

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [emailId, setEmailId] = useState('');
    const [cardNumber, setCardNumber] = useState(0);
    const [expiryMonth, setExpirayMonth] = useState();
    const [expiryDate, setExpirayDate] = useState();
    const [cvc, setCvc] = useState('');
    const [amount, setAmount] = useState(0);

    const handleFormValidation = () => {

        let formIsValid = true;

        //First name     
        if (!firstName) {
            formIsValid = false;
            toast.error('Please enter first name!')
        }
        //Last name  
        if (!lastName) {
            formIsValid = false;
            toast.error('Please enter last name!')
        }
        //Email    
        if (!validator.isEmail(emailId)) {
            toast.error('Enter valid Email!')
        }

        //credit card    
        if (!validator.isCreditCard(cardNumber)) {
            formIsValid = false;
            toast.error('Enter valid CreditCard Number!')
        }

        //amount
        if (amount < 0) {
            formIsValid = false;
            toast.error('Enter valid Amount!')
        }
        //expiry month 

        if (expiryMonth.toString().length < 2 || expiryMonth.toString().length > 2 || expiryMonth < 0) {
            toast.error('Please Enter MM format and valid month!')
        } else {
            let regMonth = /^01|02|03|04|05|06|07|08|09|10|11|12$/;
            if (!regMonth.test(expiryMonth)) {
                formIsValid = false;
                toast.error('Enter valid Month!')
            }
        }
        //expiry date
        if (expiryDate.toString().length < 2 || expiryDate.toString().length > 2 || expiryDate < 0) {
            setExpirayDate('')
            toast.error('Please Enter YY format and valid year!')
        } else {
            if (expiryDate) {
                var today = new Date(); // gets the current date
                var today_mm = today.getMonth() + 1; // extracts the month portion
                var today_yy = today.getFullYear() % 100; // extracts the year portion and changes it from yyyy to yy format

                if (today_mm < 10) { // if today's month is less than 10
                    today_mm = '0' + today_mm // prefix it with a '0' to make it 2 digits
                }

                var mm = expiryMonth;
                var yy = expiryDate;

                if (yy > today_yy || (yy == today_yy && mm >= today_mm)) {

                }
                else {
                    formIsValid = false;
                    toast.error('Enter valid Date!')
                }

            }
        }
        //cvc
        var regCVV = /^[0-9]{3,3}$/;
        if (!regCVV.test(cvc)) {
            formIsValid = false;
            toast.error('Enter valid CCV!')
        }

        return formIsValid;
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        console.log("target", value, name)
        if (name === 'first-name') {
            setFirstName(value);
        }
        if (name === 'last-name') {
            setLastName(value);
        }
        if (name === 'email') {
            setEmailId(value);
        }
        if (name === 'number') {
            setCardNumber(value);
        }
        if (name === 'month') {
            setExpirayMonth(value)
        }
        if (name === 'expiry') {
            setExpirayDate(value);
        }
        if (name === 'cvc') {
            setCvc(value);
        }
        if (name === 'amount') {
            setAmount(value);
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const form = document.querySelector('form');
        if (handleFormValidation()) {
            let data = new FormData(form);
            axios({
              method  : 'post',
              url : 'https://localhost/card-paypal/charge.php',
              data : data,
              headers: { "Content-Type": "multipart/form-data" },
            })
            .then((res)=>{
              console.log('resres',res);
            })
            .catch((err) => {throw err});
      
           
        }
    }

    return (
        <>
            <div classNameName="App">
                <form method="POST" onSubmit={handleSubmit}>
                    <div className="form-container">
                        <div className="personal-information">
                            <h1>Payment Information</h1>

                            <input className="column-left" onChange={(e) => handleChange(e)} type="text" name="first-name" placeholder="First Name" required="required" />

                            <input className="column-right" onChange={(e) => handleChange(e)} type="text" name="last-name" placeholder="Last name" required="required" />
                            <input className="input-field" onChange={(e) => handleChange(e)} type="email" name="email" required="required"  maxlength="40" placeholder="Email" />
                            <input className="input-field" onChange={(e) => handleChange(e)} type="text" name="number" placeholder="Card Number" required="required" />
                            <input className="column-left" min="0" onChange={(e) => handleChange(e)} type="number" name="month" placeholder="MM" required="required" />
                            <input className="column-right" onChange={(e) => handleChange(e)} min="0" type="number" name="expiry" placeholder="YY" required="required" />

                            <input min="0" className="column-right" onChange={(e) => handleChange(e)} type="number" name="cvc" placeholder="CCV" required="required" />

                          
                            <input min="0" className="column-left" onChange={(e) => handleChange(e)} type="number" name="amount" required="required" maxlength="40" placeholder="Amount" />
                            <input id="input-button" onChange={(e) => handleChange(e)} type="submit" value="Submit" />

                        </div>

                    </div>
                </form>
            </div>
        </>
    );
}

export default PaypalPayment;
