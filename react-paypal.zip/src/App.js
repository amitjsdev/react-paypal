import logo from './logo.svg';
import './App.css';
import PaypalPayment from './components/PaypalPayment';

function App() {
  return (
    <div className="App">
   <PaypalPayment/>
    </div>
  );
}

export default App;
