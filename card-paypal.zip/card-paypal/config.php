<?php
/*
 * Basic Site Settings and API Configuration
 */


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paypal_payment";

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);