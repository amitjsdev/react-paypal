<?php
header('Access-Control-Allow-Origin: *');
include_once 'config.php'; 
require_once "vendor/autoload.php";
  
use Omnipay\Omnipay;
  
$gateway = Omnipay::create('PayPal_Pro');
$gateway->setUsername('sb-d6fmn6639507_api1.business.example.com');
$gateway->setPassword('JDHD8Y4XS9DCXJUP');
$gateway->setSignature('AzMNkTxgBvm9UMEVF6xwI2k3UvAsAXEvsmF.TcvlqDET-lpFoF2TeLCo');
$gateway->setTestMode(true); // here 'true' is for sandbox. Pass 'false' when go live
  
 
if (isset($_POST['first-name'])) {
    $formData = array(
        'firstName' => $_POST['first-name'],
        'lastName' => $_POST['last-name'],
		'email' => $_POST['email'],
        'number' => $_POST['number'],
        'expiryMonth' => $_POST['month'],
        'expiryYear' => $_POST['expiry'],
        'cvv' => $_POST['cvc']
    );
	
 
    try {
        // Send purchase request
        $response = $gateway->purchase([
                'amount' => $_POST['amount'],
                'currency' => 'USD',
                'card' => $formData
        ])->send();

        // Process response

        if ($response->isSuccessful()) {
           // echo "Payment is successful. Your Transaction ID is: ". $response->getTransactionReference();
			
        // Insert tansaction data into the database 
        $sql = "INSERT INTO payments(first_name,last_name,email,number,month,expiry,cvc,txnid,payment_amount,payment_status) VALUES('".$_POST['first-name']."','".$_POST['last-name']."','".$_POST['email']."','".$_POST['number']."','".$_POST['month']."','".$_POST['expiry']."','".$_POST['cvc']."','".$response->getTransactionReference()."','1','USD')"; 
        $insert = $db->query($sql); 
        $last_insert_id = $db->insert_id; 
        $data['status'] = 1; 
        $data['orderID'] = $last_insert_id; 
  
        } else {
            // Payment failed
			$data['status'] = 0; 
        }
		    // Transaction status 
		echo json_encode($data); 
    } catch(Exception $e) {
        echo $e->getMessage();
    }
}